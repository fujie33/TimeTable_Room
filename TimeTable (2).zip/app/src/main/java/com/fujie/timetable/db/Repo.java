package com.fujie.timetable.db;

import android.content.Context;
import android.os.AsyncTask;

import com.fujie.timetable.db.room.TimeTableDatabase;
import com.fujie.timetable.db.room.dao.TimeTableDao;
import com.fujie.timetable.db.room.model.Course;

import java.util.List;

public class Repo {
    TimeTableDao timeTableDao;
    public List<Course> allCourse;

    public Repo(Context context) {
        TimeTableDatabase database = TimeTableDatabase.getDatabase(context.getApplicationContext());
        timeTableDao = database.getDao();
//        allCourse = timeTableDao.queryCourse();
    }

    public void InsertWords(Course... courses) {
        new InsertCourseAsyncTask(timeTableDao).execute(courses);
    }

    static class InsertCourseAsyncTask extends AsyncTask<Course, Void, Void> {
        private TimeTableDao timeTableDao;

        public InsertCourseAsyncTask(TimeTableDao dao) {
            this.timeTableDao = dao;
        }

        @Override
        protected Void doInBackground(Course... course) {
            timeTableDao.insertCourse(course);
            return null;
        }
    }
}
