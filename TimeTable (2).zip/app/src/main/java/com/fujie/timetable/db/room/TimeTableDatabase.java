package com.fujie.timetable.db.room;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import com.fujie.timetable.db.room.dao.TimeTableDao;
import com.fujie.timetable.db.room.model.Course;
import com.fujie.timetable.db.room.model.CourseTime;

@Database(entities = {Course.class, CourseTime.class}, version = 1, exportSchema = false)
public abstract class TimeTableDatabase extends RoomDatabase {
    private static TimeTableDatabase INSTANCE;

    public static synchronized TimeTableDatabase getDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(
                    context.getApplicationContext(),
                    TimeTableDatabase.class,
                    "time_table_database")
                    .build();
        }
        return INSTANCE;
    }

    public abstract TimeTableDao getDao();
}
