package com.fujie.timetable.db.room.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.fujie.timetable.db.room.model.Course;
import com.fujie.timetable.db.room.model.CourseTime;

import java.util.List;

@Dao
public interface TimeTableDao {
    @Insert
    void insertCourse(Course... course);

    @Query("select * from course")
    List<Course> queryCourse();

    @Query("select * from coursetime")
    List<CourseTime> queryCourseTime();
}
